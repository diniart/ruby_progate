score = 73

# Tambahkan sebuah pernyataan `elsif` untuk mencetak "Cukup bagus!"
if score > 80
  puts "Bagus sekali!"
elsif score >60
  puts "Cukup bagus!"
else
  puts "Anda bisa lebih baik lagi!"
end
