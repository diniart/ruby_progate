# Gabungkan "Saya adalah " dan "Ninja Ken", lalu cetak
puts "Saya adalah " + "Ninja Ken"

# Gabungkan "38" dan "19", lalu cetak

puts "38"+"19"