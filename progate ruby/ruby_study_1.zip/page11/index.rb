length = 9
width = 8
area = length * width

# Cetak "Nilai area adalah ____" menggunakan variable area
puts "Nilai area adalah #{area}"