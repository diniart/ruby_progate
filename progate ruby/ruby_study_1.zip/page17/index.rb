score = 96

# Ketika `score` lebih besar atau sama dengan 95 dan kurang dari atau sama dengan 99,
# cetak pesan "Bagus sekali! Hampir sempurna."

if score >= 95 && score <= 99
  puts "Bagus sekali! Hampir sempurna."
end