# Tetapkan string "Ninja Ken" pada variable name
name = "Ninja Ken"

# Cetak variable name
puts name
