languages = ["Jepang", "Inggris", "Spanyol"]
border = "---------------------"

languages.each do |language|
  # Cetak variable `border`
  puts border
  puts "Saya bisa berbahasa #{language}"
end

# Hapus baris code berikut ini

