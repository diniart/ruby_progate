require "./menu"

class Food < Menu
  # Tambahkan variable instance `calorie`
  attr_accessor :calorie
end
