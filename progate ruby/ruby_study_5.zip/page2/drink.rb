# Lakukan import `menu.rb` menggunakan `require`
require "./menu"

# Definisikan class `Drink yang mewarisi dari class `Menu`

def class Drink < Menu
end