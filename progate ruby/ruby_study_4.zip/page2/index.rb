# Definisikan class `Menu`

class Menu
end